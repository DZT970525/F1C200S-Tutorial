#!/bin/bash
sunxi-fel -p uboot output/images/u-boot-sunxi-with-spl.bin
