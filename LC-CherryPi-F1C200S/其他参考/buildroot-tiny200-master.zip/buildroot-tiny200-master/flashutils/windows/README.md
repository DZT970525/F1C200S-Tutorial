# F1C100s/200s Windows Flash tools

## Install Zadig Driver
1. Open zadig driver installer 
2. Choose "Device"->"Create New Device"
>![](res/Create%20New%20Device.png)
3. Install FEL mode driver
>![](res/FEL%20Driver.png)
4. Click "Install Driver"
5. Choose "Device"->"Create New Device"
>![](res/Create%20New%20Device.png)
6. Install DFU mode driver
>![](res/DFU%20Driver.png)
7. Click "Install Driver"
