import gobject  # noqa
