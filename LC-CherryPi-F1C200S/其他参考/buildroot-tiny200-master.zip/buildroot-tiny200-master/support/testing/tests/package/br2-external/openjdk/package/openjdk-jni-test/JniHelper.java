public class JniHelper
{
	public void HelloManagedWorld()
	{
		stringMember = "Hello, Managed World";
	}

	public String stringMember = "Set from Java";
}
