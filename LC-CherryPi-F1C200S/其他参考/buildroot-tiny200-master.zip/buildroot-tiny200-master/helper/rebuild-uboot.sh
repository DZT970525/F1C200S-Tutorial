#!/bin/bash
make uboot-rebuild -j8
make
